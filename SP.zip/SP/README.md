# SOCKETPIE_DOSTOOL 🌌

🛠️ DOS TOOL WITH PYTHON LAYER7 :) (HTTP FLOOD🌊)

⚙️ TECHNIQUES FLOOD (TCP FLOOD ATTACK🌊)

💥 DOWN HTTP WEBSITE TAKE ⏳6-29 SECS🌊 (SOME WEBSITE)

⚙️ (⏳DOWN HTTP SMALL SERVER💥) ⚙️

🛠️⚙️ I MADE HTTPS FLOOD NOW🌊

# INSTALL

**LINUX**
```
curl -O https://raw.githubusercontent.com/Hex1629/INSTALL_MYPROJECT/main/INSTALL_SCRIPT/socketpie.linux && bash socketpie.linux
```

**WINDOWS**
```
cd Downloads && cd SOCKETPIE_DOSTOOL-main && pip install requests && pip install colorama && python pie.py
```

# UPDATE  ⏳

IF YOU WANNA USE OLD CODE PIE PLS GO TO THIS 📁FOLDER --> FOLDER_UPDATE⚙️

(UPDATE-3_24_2023_PIE.py) <--- OLD PIE TOOL🌊

# HIT DSTAT LAYER7🚀
 📌 100K RPS IN VEDBEX DSTAT 📈(51.159.30.249)📈
 
 📌 17K RPS IN DSTATSEC.GITHUB.IO DSTAT 📈(109.71.9.87)💥
 
 📌 1.5M RPS IN DSTAT.GITHUB.IO 📈(51.15.25.108)💥
 
 📌 3M RPS IN DSTAT.XYZ 📈(Worldstream-1 - 185.132.134.228)📈
 
 💣 ATTACK SERVER ⏳(167.71.202.248)💥 
 
 💣 ATTACK NETDATA DASHBOARD ⏳(45.32.80.25)💥

 💣 ATTACK SERVER ⏳(104.253.87.11)💥

<h1>🌊 GUI SOCKET.PIE🥧 DOS TOOL 🌊</h1>

![Screenshot 2023-03-26 044624](https://user-images.githubusercontent.com/93824226/227744364-7cf31be2-bec5-4d62-97dd-c24ce6481455.png)

![Screenshot 2023-03-25 173955](https://user-images.githubusercontent.com/93824226/227744383-3436cc44-06f2-4ef9-87cf-4e5a7e4065b5.png)


<img src="https://github.com/Hex1629/SOCKETPIE_DOSTOOL/blob/main/FLOOD_MESSAGE.png"></img>
<img src="https://github.com/Hex1629/SOCKETPIE_DOSTOOL/blob/main/INPUT_ALL.png"></img>

<h1>🌊 PROOF🎬 🌊</h1>

https://user-images.githubusercontent.com/93824226/224772072-c9f767c6-e265-42dd-951a-d7238d449b1d.mp4

https://user-images.githubusercontent.com/93824226/224707531-13c89059-9537-4ac5-87a6-40f3e1508a3d.mp4

https://user-images.githubusercontent.com/93824226/224642391-d1f90a2d-4730-4bbb-939e-5231ba658fe2.mp4


# MAKE BY Hex1629 (👤🛠️)
💸 YOU CAN RESELL BUT YOU NEED TO WRITE CREDIT ME.

🛠️📁 IF YOU MAKE NEW VERSIONS WRITE CREDIT YOU TOO.

📌 DON'T FORGOT ! ! !
